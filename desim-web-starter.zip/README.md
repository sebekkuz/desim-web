# DESim Web (starter)

Monorepo: backend (Node/Express/WS), frontend (React + Vite), shared (schematy).

## Lokalnie

```bash
# Backend
cd backend
npm i
npm start

# Frontend (w innym terminalu)
cd ../frontend
npm i
npm run dev
```
